import React from 'react';

const Footer = props => {
  return (
    <div className='home-footer'>
        <p style={{fontSize: '10px'}}>Copyright © 2019 All rights reserved. 
            <span style={{color: '#8934FF'}}> VISTOGRAM</span></p>

            <p className='bottombar-cr'>© 2019 VISTOGRAM</p>
      
    </div>
  )
}

export default Footer;
